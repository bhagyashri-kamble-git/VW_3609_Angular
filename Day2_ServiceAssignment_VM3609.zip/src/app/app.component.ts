import { Component } from '@angular/core';
import { flight } from './flight';
import { flightService } from './flightService';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'my-booking-app';
  
}
