export interface Flights{
    flightName:string;
    flightNumber:number;
    fromCity:string;
    toCity:string;
    deptTime : string;
    flightStatus : string;
}