import { Component } from '@angular/core';
import { Flights } from './Flights.model';

@Component({
  selector: 'app-flight-list',
  templateUrl: './flight-list.component.html',
  styleUrl: './flight-list.component.css'
})
export class FlightListComponent {
  isShow :boolean = true;
  selectStatus :string = '';
  flights : Flights[] = [{
  flightName: 'Indigo',
  flightNumber:101,
  fromCity: 'Pune',
  toCity:'Hyd',
  deptTime : '9am',
  flightStatus : 'On Time'
},
{
  flightName: 'Spice jet',
  flightNumber:102,
  fromCity: 'Mumbai',
  toCity:'Hyd',
  deptTime : '11am',
  flightStatus : 'Delayed'
},
{
  flightName: 'Air-india',
  flightNumber:103,
  fromCity: 'Mumbai',
  toCity:'Chennai',
  deptTime : '12.30pm',
  flightStatus : ' '
},
{
  flightName: 'Air-india',
  flightNumber:104,
  fromCity: 'Cochi',
  toCity:'Pune',
  deptTime : '2.30pm',
  flightStatus : 'Cancelled '
}]


}
