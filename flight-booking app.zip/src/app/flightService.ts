import { flight } from "./flight";

export class flightService{

     public getFlights(){
            let flights : flight[];
            flights = [new flight(101,'PUNE','MUM','9am','indigo',100,10),
            new flight(102,'HYD','COCHI','10am','indigo',100,10),
            new flight(103,'NAGR','HYD','11am','indigo',100,10),
            new flight(104,'DELHI','PUNE','8am','spicejet',100,10),
            new flight(105,'CHENNAI','PUNE','7am','spicejet',100,10),
            ]
            return flights;
     }
     
}