import { Component } from '@angular/core';
import { flightService } from '../flightService';
import { flight } from '../flight';

@Component({
  selector: 'app-flight-details-sharing',
  templateUrl: './flight-details-sharing.component.html',
  styleUrl: './flight-details-sharing.component.css'
})
export class FlightDetailsSharingComponent {
 /*flightService : flightService | undefined
 flights!: flight[] | undefined;
 flightDetails : flight[] |undefined
 bookingMsg : string =''
  constructor(){
    this.flightService = new flightService();
    this.bookingMsg = '';
  }
  ngOnInit(){
    this.getFlights();
  }
  bookflight(){
      this.flightDetails = this.flights ;
  }
  getFlights() : any {
    this.flights = this.flightService?.getFlights();
 }
 receiveBooking(event :any){
  alert("received")
  this.bookingMsg = event;
 }*/
}
