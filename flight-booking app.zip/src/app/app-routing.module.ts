import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FlightComponent } from './flight/flight.component';
import { FlightListComponent } from './flight-list/flight-list.component';
import { FlightDetailsShowComponent } from './flight-details-show/flight-details-show.component';

const routes: Routes = [
  {
    path: 'flight/',
    component: FlightComponent,
    children: [
      { path: 'list', component: FlightListComponent },
      { path: 'details', component: FlightDetailsShowComponent },
      { path: '', redirectTo: 'list', pathMatch: 'full' }
    ]
  },
  { path: '', redirectTo: '/flight/', pathMatch: 'full' }, // default route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
