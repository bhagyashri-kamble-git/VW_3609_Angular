import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { flight } from '../flight';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-flight-details-show',
  templateUrl: './flight-details-show.component.html',
  styleUrl: './flight-details-show.component.css'
})
export class FlightDetailsShowComponent implements OnInit {
  flightNumber:number | undefined
  constructor(private router :ActivatedRoute ){

  }
  ngOnInit(): void {
    this.flightNumber =Number(this.router.snapshot.paramMap.get('flightNumber')!);
  }
  /*@Input() // get data from parent
  flightDetailsToChild : flight[] |undefined

  @Output() //send event to parent
  childevent = new EventEmitter();
  
  bookflight(){
    this.childevent.emit("Booking is successful");
  }*/
}
