import { Component } from '@angular/core';
import { flightService } from '../flightService';
import { flight } from '../flight';

@Component({
  selector: 'app-new-flight-list',
  templateUrl: './new-flight-list.component.html',
  styleUrl: './new-flight-list.component.css'
})
export class NewFlightListComponent {
  flightService : flightService | undefined;
  flights : flight[] | undefined;
  public model : any ={};
  public bookingList : Array<any> = [];

  
  constructor(){
    //this.flightService = new flightService();
    }
  ngOnInit(){
    this.getFlights();
  }
  getFlights() : any {
     //this.flights = this.flightService?.getFlights();
  }
  bookflight():void{
   this.flights?.push(this.model);
   this.model = {}
  }
  getAllBookingDetails() : any{
    return this.flights;
 }

}
