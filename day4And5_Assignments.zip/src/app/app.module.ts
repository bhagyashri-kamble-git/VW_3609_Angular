import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FlightListComponent } from './flight-list/flight-list.component';
import { NewFlightListComponent } from './new-flight-list/new-flight-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlightFormComponent } from './flight-form/flight-form.component';
import { FlightDetailsSharingComponent } from './flight-details-sharing/flight-details-sharing.component';
import { FlightDetailsShowComponent } from './flight-details-show/flight-details-show.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { PassengerFormComponent } from './passenger-form/passenger-form.component';
import { FlightComponent } from './flight/flight.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    FlightListComponent,
    NewFlightListComponent,
    FlightFormComponent,
    FlightDetailsSharingComponent,
    FlightDetailsShowComponent,
    ReactiveFormComponent,
    PassengerFormComponent,
    FlightComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
