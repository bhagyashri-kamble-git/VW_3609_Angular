import { Component } from '@angular/core';
import { flight } from './flight.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-flight-form',
  templateUrl: './flight-form.component.html',
  styleUrl: './flight-form.component.css'
})
export class FlightFormComponent {
  /*flight = new flight();
  flights : flight[] | undefined;
  

  onSubmit(form:any) {
    if(form.valid){
       console.log(' Flight details is submitted ', this.flight)
       alert("Flight booking successful");
       this.flights?.push(this.flight);
       //form.resetForm()
    }
  }*/
  flightForm!: FormGroup;
  
 constructor(private fb:FormBuilder)
  {
    this.flightForm = this.fb.group({
      passengerName: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      pnumber: [null,[Validators.required,Validators.minLength(10),]],
      deptAir:['',Validators.required],
      arrAir:['',Validators.required],
      tDate:['',Validators.required],
      PassengerNumbers: [null,[Validators.required,Validators.min(1),Validators.max(10)]],
    })
  }

 onSubmit(){
  if(this.flightForm.valid){
    console.log(' Flight data is ', this.flightForm.value)
    alert(' Flight saved !!')
  }
  else{
    this.flightForm.markAllAsTouched();
  }
 }

 get f(){
  return this.flightForm.controls;
 }
}
