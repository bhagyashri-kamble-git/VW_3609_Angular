

export class flight {

    constructor(
     public flightNumber:number=0,
     public deptCity:string =' ',
     public arrivalCity:string =' ',
     public deptDate:string ='  ',
     public availableSeats:number =0,
     public flightClass:string ='  ',
    ){}
    
 }