export interface Flight{
    flightNumber?:string;
    airline: string;
    from:string;
    to:string;
    departureTime:string;
    arrivalTime:string;
    duration:string;
    price : string;
    currency : string;
    seatsAvailable :number;
    status:string
}
