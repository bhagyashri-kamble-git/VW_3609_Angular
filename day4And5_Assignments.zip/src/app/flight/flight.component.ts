import { Component, OnInit } from '@angular/core';
import { Flight } from './flight.model';
import { flightService } from '../flightService';

@Component({
  selector: 'app-flight',
  templateUrl: './flight.component.html',
  styleUrl: './flight.component.css'
})
export class FlightComponent implements OnInit{

  editing :boolean = false;
 
  editFlight: Flight = {flightNumber:'',airline:'',from:'',to:''
  ,departureTime:'',arrivalTime:'',duration:''
  ,price:'',currency:'',seatsAvailable:0,status:''}
  searchText :string = ''
  startEdit(f: Flight): void {
    this.editing = true;
    this.editFlight = {...f}
  }

 flights: any = [];

 newFlight : Flight = {flightNumber:'',airline:'',from:'',to:''
 ,departureTime:'',arrivalTime:'',duration:''
 ,price:'',currency:'',seatsAvailable:0,status:''}

 constructor(private flightservice: flightService){}

  ngOnInit(): void {
    this.fetchFlight();
  }

  fetchFlight():void{
    this.flightservice.getFlights().subscribe(data => {
      console.log(data)
      this.flights = data;
    })
  }

  createFlight(): void{

    if(!this.newFlight.flightNumber ||!this.newFlight.airline){
      console.log("flightNumber and airline are required")
      return
    }

    this.flightservice.addFlight(this.newFlight).subscribe(flight =>{
      
      this.flights.push(flight)
      this.newFlight = {flightNumber:'',airline:'',from:'',to:''
      ,departureTime:'',arrivalTime:'',duration:''
      ,price:'',currency:'',seatsAvailable:0,status:''}
    })

  }

  updateFlight(): void{
    if(!this.editFlight.flightNumber) return 

    this.flightservice.updateFlight(this.editFlight.flightNumber, this.editFlight).subscribe(updated => {
      const index = this.flights.findIndex(f => f.flightNumber === updated.flightNumber)
      if( index !== -1)
        this.flights[index] = updated;
      this.editing= false;
      this.editFlight = {flightNumber:'',airline:'',from:'',to:''
      ,departureTime:'',arrivalTime:'',duration:''
      ,price:'',currency:'',seatsAvailable:0,status:''}
    })
  }

  deleteFlight(flightNumber:string) :void {
    this.flightservice.deleteFlight(flightNumber).subscribe( () =>{
      this.flights = this.flights.filter(f => f.flightNumber !== flightNumber)
    })
  }
}
