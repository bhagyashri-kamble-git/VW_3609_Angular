export class flight{
    flightNumber :number | undefined ;
    origin :string | undefined;
    destination : string | undefined;
    deptTime : string| undefined;
    flightType : string| undefined;
    totalSeats : number| undefined;
    availableSeats :number| undefined;

    constructor(flightNumber :number,origin :string,destination : string,deptTime : string,
        flightType : string,totalSeats : number, availableSeats :number){
            this.flightNumber = flightNumber;
            this.origin = origin;
            this.destination= destination;
            this.deptTime = deptTime;
            this.flightType = flightType;
            this.totalSeats = totalSeats;
            this.availableSeats = availableSeats;
    }
}