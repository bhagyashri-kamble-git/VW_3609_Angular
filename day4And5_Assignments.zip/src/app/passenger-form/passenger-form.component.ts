import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-passenger-form',
  templateUrl: './passenger-form.component.html',
  styleUrl: './passenger-form.component.css'
})
export class PassengerFormComponent {

  passengerForm!: FormGroup;
  
 constructor(private fb:FormBuilder)
  {
    this.passengerForm = this.fb.group({
      passengerName: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      pnumber: [null,[Validators.required,Validators.minLength(10),]],
      passportnumber:[null,[Validators.required,Validators.minLength(10)]],
      bdate:['',Validators.required],
      nationality: [null,[Validators.required]],
    })
  }

 onSubmit(){
  if(this.passengerForm.valid){
    console.log('Passenger data is ', this.passengerForm.value)
    alert(' Passenger data saved !!')
  }
  else{
    this.passengerForm.markAllAsTouched();
  }
 }

 get f(){
  return this.passengerForm.controls;
 }
}
