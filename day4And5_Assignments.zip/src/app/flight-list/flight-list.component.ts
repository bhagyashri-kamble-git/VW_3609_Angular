import { Component, OnInit } from '@angular/core';
import { Flights } from './Flights.model';
import { ActivatedRoute } from '@angular/router';
import { flight } from '../flight';

@Component({
  selector: 'app-flight-list',
  templateUrl: './flight-list.component.html',
  styleUrl: './flight-list.component.css'
})
export class FlightListComponent implements OnInit  {
  flightNumber:number | undefined
  flights : any [] = []
  constructor(private router :ActivatedRoute){

  }
  
  
  ngOnInit(): void {
    
    this.flights = [{
      flightName: 'Indigo',
      flightNumber:101,
      fromCity: 'Pune',
      toCity:'Hyd',
      deptTime : '9am',
      flightStatus : 'On Time'
    },
    {
      flightName: 'Spice jet',
      flightNumber:102,
      fromCity: 'Mumbai',
      toCity:'Hyd',
      deptTime : '11am',
      flightStatus : 'Delayed'
    },
    {
      flightName: 'Air-india',
      flightNumber:103,
      fromCity: 'Mumbai',
      toCity:'Chennai',
      deptTime : '12.30pm',
      flightStatus : ' '
    },
    {
      flightName: 'Air-india',
      flightNumber:104,
      fromCity: 'Cochi',
      toCity:'Pune',
      deptTime : '2.30pm',
      flightStatus : 'Cancelled '
    }];
  }
  isShow :boolean = true;
  selectStatus :string = '';


bookFlight(flightnumber : number){
 alert("flight booked");
}
}

