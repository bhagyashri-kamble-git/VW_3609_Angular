import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightDetailsSharingComponent } from './flight-details-sharing.component';

describe('FlightDetailsSharingComponent', () => {
  let component: FlightDetailsSharingComponent;
  let fixture: ComponentFixture<FlightDetailsSharingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FlightDetailsSharingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FlightDetailsSharingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
