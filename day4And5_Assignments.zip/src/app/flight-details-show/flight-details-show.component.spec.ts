import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightDetailsShowComponent } from './flight-details-show.component';

describe('FlightDetailsShowComponent', () => {
  let component: FlightDetailsShowComponent;
  let fixture: ComponentFixture<FlightDetailsShowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FlightDetailsShowComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FlightDetailsShowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
