import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrl: './reactive-form.component.css'
})
export class ReactiveFormComponent {
 
  productForm!: FormGroup;

  constructor(private fb:FormBuilder)
  {
    this.productForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      price: [null,[Validators.required,Validators.min(10.00)]],
      description:[''],
      category:['',Validators.required]
    })
  }

 onSubmit(){
  if(this.productForm.valid){
    console.log(' Product data is ', this.productForm.value)
    alert(' Product saved !!')
  }
  else{
    this.productForm.markAllAsTouched();
  }
 }

 get f(){
  return this.productForm.controls;
 }


}
