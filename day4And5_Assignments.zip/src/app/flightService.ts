import { HttpClient } from "@angular/common/http";

import { Flight } from "./flight/flight.model";
import { Observable } from "rxjs";
import { Injectable } from "@angular/core";


@Injectable({
  providedIn: 'root'
})
export class flightService{

    /* public getFlights(){
            let flights : flight[];
            flights = [new flight(101,'PUNE','MUM','9am','indigo',100,10),
            new flight(102,'HYD','COCHI','10am','indigo',100,10),
            new flight(103,'NAGR','HYD','11am','indigo',100,10),
            new flight(104,'DELHI','PUNE','8am','spicejet',100,10),
            new flight(105,'CHENNAI','PUNE','7am','spicejet',100,10),
            ]
            return flights;
     }*/
     private apiUrl = 'https://mocki.io/v1/fcce0040-895b-47cf-a2a0-d7250e71d4e9'

     constructor(private http: HttpClient) { }
   
     getFlights() : Observable<Flight[]>{
      return this.http.get<Flight[]>(this.apiUrl)
     }
   
     addFlight(flight: Flight) :Observable<Flight>{
       return this.http.post<Flight>(this.apiUrl, flight)
     }
   
     updateFlight(flightNumber:string, flight: Flight) : Observable<Flight>{
       console.log(`------- ${this.apiUrl}/${flightNumber}`)
       console.log(flight)
       return this.http.put<Flight>(`${this.apiUrl}/${flightNumber}`, flight)
     }
   
     deleteFlight(flightNumber:string) : Observable<void>{
       return this.http.delete<void>(`${this.apiUrl}/${flightNumber}`)
     }
     
}